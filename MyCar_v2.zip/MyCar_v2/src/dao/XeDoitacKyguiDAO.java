package dao;

public class XeDoitacKyguiDAO {

}
